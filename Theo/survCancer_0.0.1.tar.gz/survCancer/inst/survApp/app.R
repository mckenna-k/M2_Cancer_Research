library(shiny)
library(shinydashboard)
library(ggplot2)
library(survival)

ui <- dashboardPage(
  dashboardHeader(title = 'Cancer trends'),
  dashboardSidebar(
    sidebarMenu(
      id = "tabs",
      menuItem("Simulations", tabName = "simu", icon = NULL),
      menuItem("Data", tabName = "data", icon = NULL),
      menuItem("Cox", tabName = "cox", icon = NULL)
    ),
    conditionalPanel("input.tabs == 'simu'",
                     numericInput("nbIndivSimu","Nombre d'individus",value=100,min=1,max=1000),
                     numericInput("l01Simu","Paramètre de transition 0 à 1",value=0.3,min=0.01,max=10),
                     numericInput("l12Simu","Paramètre de transition 1 à 2",value=0.3,min=0.01,max=10),
                     numericInput("l02Simu","Paramètre de transition 0 à 2",value=0.3,min=0.01,max=10),
                     numericInput("censoredSimu","Paramètre de censure (0 = sans)",value=0,min=0,max=10),
                     numericInput("sSimu","Etat 0 à t=",value=0,min=0,max=10),
                     sliderInput("timeSurvSimu","limit x-axis",min=1,max=30,value=15),
                     sliderInput("timeProbSimu","limit x-axis",min=1,max=30,value=15)
    ),
    conditionalPanel("input.tabs == 'data'",
                     uiOutput("cancerTypeUI"),
                     sliderInput("timeSurv","limit x-axis",min=1,max=30,value=10),
                     numericInput("s","Etat 0 à t=",value=0,min=0,max=10),
                     sliderInput("timeProb","limit x-axis",min=1,max=30,value=10)
    ),
    conditionalPanel("input.tabs == 'cox'",
                     uiOutput("cancerTypeCoxUI")
    )
  ),
  dashboardBody(
    tabItems(
      tabItem("simu",
              plotOutput("survPlotSimu"),
              plotOutput("probPlotSimu"),
      ),
      tabItem("data",
              fluidRow(
                plotOutput("survPlot"),
                plotOutput("probPlot"),
                textOutput("nbIndiv"),
                uiOutput("parameters")
              )
      ),
      tabItem("cox",
              fluidRow(
                plotOutput("survPlotCox",height = "600px"),
                tableOutput("nbIndivCovar"),
                tableOutput("coxCoeff")
              )
      )
    )
  )
)

server <- function(input, output){
  TCGA <- reactiveValues(data=get("TCGA","package:survCancer",inherits = FALSE))
  df_data <- reactiveVal()
  df_data_stage <- reactiveVal()

  observeEvent(TCGA$data,{
    data <- TCGA$data
    data$DSS.time <- as.numeric(data$DSS.time) #en entrée, les valeurs peuvent être des caractères
    data$DSS <- as.numeric(data$DSS)
    data$PFI.time <- as.numeric(data$PFI.time)
    data$PFI <- as.numeric(data$PFI)
    data$DSS.time[data$DSS.time==0] <- NA #enlève les suivis nuls
    data$PFI.time[data$PFI.time==0] <- NA
    data$DSS.time[data$PFI.time > data$DSS.time] <- NA #enlève les tumeurs apparues après la mort
    data$PFI.time[data$PFI.time > data$DSS.time] <- NA

    pfiNotDead.time <- data$PFI.time/365.25 #temps auquel la maladie se déclare 0 -> 1, le temps est mis en années
    pfiNotDead <- data$PFI
    pfiNotDead[data$PFI.time==data$DSS.time] <- 0 #censuré si le temps de PFI est égal à la mort
    dssDirect.time <- data$DSS.time/365.25 #temps pour la mort sans maladie préalable, 0 -> 2
    dssDirect <- data$DSS
    dssDirect[!data$PFI.time==data$DSS.time] <- 0
    dssRelapse.time <- (data$DSS.time-data$PFI.time)/365.25  #temps de de la mort à partir de la maladie, 1 -> 2
    dssRelapse.time[pfiNotDead==0] <- 0
    dssRelapse <- data$DSS
    dssRelapse[data$PFI.time==data$DSS.time] <- 0

    stage <- as.factor(data$ajcc_pathologic_tumor_stage) #stade de la tumeur
    levels(stage) <- c("NA","NA","NA","NA","I - II","I - II","other","I - II","I - II","I - II","I - II","I - II","I - II","I - II","III - IV","III - IV","III - IV","III - IV","III - IV","III - IV","III - IV","III - IV","other") #simplification des classes et nettoyage
    stageBis <- as.factor(data$clinical_stage) #stade clinique
    levels(stageBis) <- c("NA","NA","NA","I - II","I - II","I - II","III - IV","III - IV","III - IV",rep("I - II",14),rep("III - IV",6),"I - II",rep("III - IV",4)) #simplification des classes et nettoyage
    stage <- sapply(1:length(stage),function(i){
      if(stage[i]=="NA") return(stageBis[i])
      else return(stage[i])
    })  #la variable est composé de préférence du stade de la tumeur puis du stade clinique

    df_new <- data.frame("DSS"=data$DSS,"DSS.time"=data$DSS.time/365.25,   #construction de la data frame
                         "PFI"=data$PFI,"PFI.time"=data$PFI.time/365.25,
                         "T01"=pfiNotDead,"T01.time"=pfiNotDead.time,
                         "T02"=dssDirect,"T02.time"=dssDirect.time,
                         "T12"=dssRelapse,"T12.time"=dssRelapse.time,
                         stage,"type"=data$type)
    df_new <- df_new[-which(apply(df_new,1,function(x) any(is.na(x)))),]  #nettoyage des NA sans stage
    df_data(df_new)
    df_new <- df_new[-which(is.element(df_new$stage,c("NA","other"))),] #nettoyage des NA du stage
    df_new$stage <- factor(df_new$stage,c("I - II","III - IV"))
    df_data_stage(df_new)
  })

  data_simu <- reactiveVal()

  observeEvent({input$nbIndivSimu
    input$l01Simu
    input$l02Simu
    input$l12Simu
    input$censoredSimu},{
      if(input$censoredSimu==0) data_simu(process(input$nbIndivSimu,input$l01Simu,input$l02Simu,input$l12Simu))
      else data_simu(process(input$nbIndivSimu,input$l01Simu,input$l02Simu,input$l12Simu,input$censoredSimu))
    })

  output$survPlotSimu <- renderPlot({ req(input$timeSurvSimu); plot_process_KM(data_simu(),time_limit = input$timeSurvSimu) })
  output$probPlotSimu <- renderPlot({ req(input$timeProbSimu); plot_process_prob(data_simu(),input$sSimu,input$l01Simu,input$l02Simu,input$l12Simu,time_limit = input$timeProbSimu) })

  output$cancerTypeUI <- renderUI({
    selectInput("cancerType","Cancer types",choices=unique(df_data()$type),selected = "CHOL")
  })

  output$survPlot <- renderPlot({
    req(input$cancerType,input$timeSurv)
    df <- df_data()[df_data()$type==input$cancerType,]
    plot_process_KM(df,time_limit=input$timeSurv)
  })

  output$probPlot <- renderPlot({
    req(input$cancerType,input$timeProb)
    df <- df_data()[df_data()$type==input$cancerType,]
    plotParam <- plot_process_prob(df,input$s,time_limit=input$timeProb)
    output$parameters <- renderUI({ print(paste0("l01 = ",round(plotParam[[2]],5),", l02 = ",round(plotParam[[3]],5),", l12 = ",round(plotParam[[4]],5))) })
    plotParam[[1]] #affichage du graphe
  })

  output$nbIndiv <- renderText({
    req(input$cancerType)
    df <- df_data()[df_data()$type==input$cancerType,]
    print(paste0("Nombre d'individus = ",nrow(df)))
  })

  output$cancerTypeCoxUI <- renderUI({
    selectInput("cancerTypeCox","Cancer types",choices=unique(df_data()$type),selected = "CHOL")
  })

  output$survPlotCox <- renderPlot({
    req(input$cancerTypeCox)
    df <- df_data_stage()[df_data_stage()$type==input$cancerTypeCox,]
    plot_process_KM(df,rep(df$stage,5),NULL)
  })

  output$nbIndivCovar <- renderTable({
    req(input$cancerTypeCox)
    df <- df_data_stage()[df_data_stage()$type==input$cancerTypeCox,]
    display <- data.frame(sapply(seq(1,10,2),function(i) sapply(unique(df$stage),function(j) as.integer(sum(df[,i][df$stage==j])))))
    display <- cbind(sapply(unique(df$stage),function(j) length(df[,1][df$stage==j])),c(NA,NA),display)
    rownames(display) <- unique(df$stage)
    colnames(display) <- c("Total","Non censurées","DSS","PFI","T01","T02","T12")
    display
  },rownames=TRUE)

  output$coxCoeff <- renderTable({
    req(input$cancerTypeCox)
    df <- df_data_stage()[df_data_stage()$type==input$cancerTypeCox,]
    res <- cbind(t(sapply(seq(1,10,2),function(i) summary(coxph(Surv(df[,i+1],df[,i])~stage,data=df))$coefficients[c(2,5)])),c(NA,NA))
    rownames(res) <- c("DSS","PFI","T01","T02","T12")
    colnames(res) <- c(colnames(summary(coxph(Surv(df[,2],df[,1])~stage,data=df))$coefficients)[c(2,5)],rownames(summary(coxph(Surv(df[,2],df[,1])~stage,data=df))$coefficients))
    res
  },rownames=TRUE,digits=-2)
}
shinyApp(ui,server)

