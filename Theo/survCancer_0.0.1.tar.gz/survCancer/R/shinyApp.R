#' Launch the corresponding shiny application
#'
#' @import shiny
#' @import shinydashboard
#' @import ggplot2
#' @import survival
#'
#' @return the application
#' @export
#'
survApp <- function() {appDir <- system.file("survApp",package="survCancer");shiny::runApp(appDir, display.mode = "normal")}
