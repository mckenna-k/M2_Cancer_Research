#' A utiliser avec facet_grid_custom
#'
#' @param which the facet that the function will be applied to
#' @param scale a scale parameter
#'
#' @return une liste de classe scale_override
#'
scale_override <- function(which, scale) {
  if(!is.numeric(which) || (length(which) != 1) || (which %% 1 != 0)) {
    stop("which must be an integer of length 1")
  }

  if(is.null(scale$aesthetics) || !any(c("x", "y") %in% scale$aesthetics)) {
    stop("scale must be an x or y position scale")
  }

  structure(list(which = which, scale = scale), class = "scale_override")
}
