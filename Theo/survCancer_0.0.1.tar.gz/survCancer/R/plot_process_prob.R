#' Title
#'
#' @param data
#'
#' @return
#' @export
#'
#' @examples
plot_process_prob <- function(data,begin=0,l01=NULL,l02=NULL,l12=NULL,time_limit=10){
  time00 <- data$T01.time  #temps de passage de l'état 0 à 1
  time00[data$T02==1] <- data$T02.time[data$T02==1] #on remplace les temps censurés de T01 par ceux de T02, pour créer les temps de départ de 0.
  support00 <- survfit(Surv(time00[time00 >= begin],(data$T01+data$T02)[time00 >= begin])~1)  #n.event, n.risk pour cet événement
  support11 <- survfit(Surv(data$T12.time[data$T01.time + data$T12.time >= begin],data$T12[data$T01.time + data$T12.time >= begin])~1)
  support01 <- survfit(Surv(data$T01.time[data$T01.time >= begin],data$T01[data$T01.time >= begin])~1)

  time <- sort(union(data$T01.time,data$T02.time)) #temps total, incluant toutes les temporalités
  time <- time[time >= begin]                      #telles qu'elles soient après begin

  surv00 <- sapply(time,function(t){    #extension du kaplan-Meier sur tout time, donc avec répétition des valeurs si nécessaire
    if(t %in% support00$time) return(support00$surv[support00$time==t])
    else{
      ind <- max(which(support00$time<=t))
      if(ind > 0) return(support00$surv[ind])
      else return(1)
    }
  })
  n.event01 <- sapply(time,function(t){    #nombre d'événement de la transition 0 -> 1 étendu à tout time
    if(t %in% support01$time) return(support01$n.event[support01$time==t])
    else return(0)
  })
  n.risk00 <- sapply(time,function(t){    #nombre d'individus à risque qui quittent 0 étendu à tout time
    if(t %in% support00$time) return(support00$n.risk[support00$time==t])
    else{
      ind <- max(which(support00$time<=t))
      if(ind > 0) return(support00$n.risk[ind])
      else return(1)
    }
  })
  cumHazInc01 <- n.event01/n.risk00   #utilisé dans le calcul de p01
  invSurv11 <- sapply(time,function(t){      # calcul de p11(0,t-u) avec u étant un temps du processus entre 0 et t
    vec <- sapply(t - time[time <= t],function(y){
      h <- sum(support11$time <= y)
      return(prod(1-(support11$n.event[1:h]/support11$n.risk[1:h])))
    })
    return(c(vec,rep(0,length(time)-length(vec))))
  })
  p00 <- surv00  #kaplan-meier sur l'événement 'quitter 0'
  p01 <- apply(c(1,surv00[-length(surv00)])*cumHazInc01*invSurv11,2,sum)
  p02 <- 1 - (p00 + p01)
  p11 <- support11$surv #kaplan-meier sur 1 -> 2
  p12 <- 1- p11

  if(is.null(l01) | is.null(l02) | is.null(l12)){   #ajuste les paramètres l01, etc aux courbes par moindre carrés avec les courbes théoriques
    grid <- seq(0.00001,1/mean(data$T01.time),length.out=100)
    res <- sapply(grid,function(i){
      pred_vec <- exp(-i*(time-begin))
      return(sum((p00-pred_vec)^2))
    })
    l012 <- grid[which.min(res)]

    grid2 <- seq(0.00001,1/mean(data$T12.time),length.out=100)
    res <- sapply(grid2,function(i){
      pred_vec <- exp(-i*(support11$time-begin))
      return(sum((p11-pred_vec)^2))
    })
    l12 <- grid2[which.min(res)]

    res <- sapply(grid,function(i){
      pred_vec <- sapply((time-begin),function(u) integrate(function(x) exp(-l012*x)*i*exp(-(u-x)*l12),0,u)$value)
      return(sum((p01-pred_vec)^2))
    })
    l02 <- l012-grid[which.min(res)]
    l01 <- grid[which.min(res)]
  }

  df_proba <- data.frame("time"=c(rep(time,3),rep(support11$time,2)),
                         "proba"=c(p00,p01,p02,p11,p12),
                         "courbes"=c(rep(c("p00","p01","p02"),each=length(time)),rep(c("p11","p12"),each=length(support11$time))),
                         "etat_initial"=c(rep(paste0("Etat initial 0 à t=",begin),length(time)*3),rep("Etat initial 1",length(support11$time)*2)),
                         "exact"=c(exp(-(l01+l02)*(time-begin)),
                                   sapply((time-begin),function(u) integrate(function(x) exp(-(l01+l02)*x)*l01*exp(-(u-x)*l12),0,u)$value),
                                   1-exp(-(l01+l02)*(time-begin))-sapply((time-begin),function(u)integrate(function(x) exp(-(l01+l02)*x)*l01*exp(-(u-x)*l12),0,u)$value),
                                   exp(-l12*(support11$time-begin)),
                                   1-exp(-l12*(support11$time-begin))
                         )
  )

  g <- ggplot(df_proba)+
    geom_step(aes(time,proba,color=courbes))+
    geom_line(aes(time,exact,color=courbes),alpha=0.25,size=0.5)+
    facet_wrap(~etat_initial)+
    theme_minimal()+
    coord_cartesian(ylim = c(0,1),xlim=c(begin,time_limit))
  return(list(g,l01,l02,l12))
}
