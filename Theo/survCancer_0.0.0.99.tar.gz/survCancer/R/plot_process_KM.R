#' Title
#'
#' @param data
#' @param covar
#'
#' @return
#' @export
#'
#' @examples
plot_process_KM <- function(data,covar=NULL,time_limit=10){
  df <- data.frame("time"=c(data$DSS.time,data$PFI.time,data$T01.time,data$T02.time,data$T12.time,data$T12reset.time),"event"=c(data$DSS,data$PFI,data$T01,data$T02,data$T12,data$T12reset),"transitions"=rep(c("DSS","PFI","T01","T02","T12","T12reset"),each=nrow(data)))
  if(is.null(covar)){
    support <- survfit(Surv(df$time,df$event)~transitions,data=df)
    new_df <- data.frame("time"=rep(support$time,2),"val"=c(support$surv,support$cumhaz),"transitions"=rep(rep(names(support$strata),support$strata),2),"type"=rep(c("Survival","Cumulative hazard"),each=length(support$time)))
  }
  else{
    support <- survfit(Surv(df$time,df$event)~transitions+covar,data=df)
    new_df <- data.frame("time"=support$time,"val"=support$surv,"transitions"=rep(rep(c(substr(names(support$strata)[seq(1,5*length(unique(covar)),length(unique(covar)))],1,15),substr(names(support$strata)[6*length(unique(covar))],1,20)),each=2),support$strata),"stage"=rep(rep(substr(names(support$strata)[1:length(unique(covar))],17,1000),6),support$strata))
  }
  debut <- new_df$transitions
  debut[new_df$transitions=="transitions=T12reset"] <- "From state 1"
  debut[new_df$transitions!="transitions=T12reset"] <- "From 0"
  new_df$transitions[new_df$transitions=="transitions=T12reset"] <- "transitions=T12"
  new_df <- cbind(new_df,debut)

  if(is.null(covar)){
    g <- ggplot(new_df)+
      geom_step(aes(time,val,color=transitions,linetype=debut))+
      geom_point(aes(time,val,color=transitions),data = new_df[df$event==0,],shape=4)+
      facet_wrap_custom(~type,scales="free_y",scale_overrides=list(scale_override(2,ylim(c(0,1)))))+  #comme facet_grid mais permet de gérer la taille des panneaux de manière individuelle
      coord_cartesian(xlim = c(0,ifelse(is.null(time_limit),max(new_df$time),time_limit)))+
      theme_minimal()
  }
  else{
    g <- ggplot(new_df)+
    geom_step(aes(time,val,color=stage,linetype=debut))+
    geom_point(aes(time,val,color=stage),data = new_df[df$event==0,],shape=4)+
    facet_wrap(~transitions,scales = "free_y")+
    coord_cartesian(xlim = c(0,ifelse(is.null(time_limit),max(new_df$time),time_limit)),ylim=c(0,1))+
    theme_minimal()
  }
  return(g)
}
