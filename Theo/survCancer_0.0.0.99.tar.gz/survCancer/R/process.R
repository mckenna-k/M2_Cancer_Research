#' Title
#'
#' @param n
#' @param l01
#' @param l02
#' @param l12
#'
#' @return
#' @export
#'
#' @examples
process <- function(n,l01,l02,l12){
  t1 <- rexp(n,l01+l02) #temps de passage de 0 à 1 ou 0 à 2
  s1 <- rbinom(n,1,l01/(l01+l02))+1 #détermination de l'état atteint (1 ou 2)
  t2 <- rexp(n,l12) #temps absolu de passage de l'état 1 à 2

  df <- data.frame("DSS"=rep(1,n),"DSS.time"=ifelse(s1==1,t1+t2,t1),
                   "PFI"=rep(1,n),"PFI.time"=ifelse(s1==1,t1,t2),
                   "T01"=-(s1-2),"T01.time"=t1,
                   "T02"=ifelse(s1==2,1,0),"T02.time"=ifelse(s1==2,t1,t1+t2),
                   "T12"=-(s1-2),"T12.time"=ifelse(s1==1,t1+t2,t1),
                   "T12reset"=-(s1-2),"T12reset.time"=ifelse(s1==1,t2,t1))
  return(df)
}
