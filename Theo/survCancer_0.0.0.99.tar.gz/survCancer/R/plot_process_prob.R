#' Title
#'
#' @param data
#'
#' @return
#' @export
#'
#' @examples
plot_process_prob <- function(data,time_limit=10){
  time00 <- data$T01.time
  time00[data$T02==1] <- data$T02.time[data$T02==1]
  support00 <- survfit(Surv(time00,data$T01+data$T02)~1)
  support11 <- survfit(Surv(data$T12.time,data$T12)~1)
  support01 <- survfit(Surv(data$T01.time,data$T01)~1)
  support12_reset <- survfit(Surv(data$T12reset.time,data$T12reset)~1)

  KM <- function(begin,end,n.event,n.risk,time) return(prod(1-(n.event/n.risk)[time > begin & time <= end]))

  time <- sort(union(data$T01.time,data$T02.time))
  n.event01 <- sapply(time,function(t){
    if(t %in% support01$time) return(support01$n.event[support01$time==t])
    else return(0)
  })
  n.risk00 <- sapply(time,function(t){
    if(t %in% support00$time) return(support00$n.risk[support00$time==t])
    else{
      if(max(support00$time[support00$time<=t]) >= 0) return(support00$n.risk[support00$time==max(support00$time[support00$time<=t])])
      else return(1)
    }
  })
  cumHazInc01 <- n.event01/n.risk00
  p00 <- sapply(time,function(t) KM(0,t,support00$n.event,support00$n.risk,support00$time))
  prod1 <- sapply(1:length(time),function(j) ifelse(j==1,1,KM(0,time[[j-1]],support00$n.event,support00$n.risk,support00$time)) * cumHazInc01[[j]])
  p01 <- sapply(1:length(time),function(i) sum(sapply(1:i,function(j) prod1[[j]] * KM(time[[j]],time[[i]],support11$n.event,support11$n.risk,support11$time))))
  p02 <- 1 - (p00 + p01)
  p11 <- sapply(time,function(t) KM(0,t,support11$n.event,support11$n.risk,support11$time))
  p12 <- 1- p11

  p01reset <- sapply(1:length(time),function(i) sum(sapply(1:i,function(j) prod1[[j]] * KM(time[[j]],time[[i]],support12_reset$n.event,support12_reset$n.risk,support12_reset$time))))
  p02reset <- 1 - (p00 + p01reset)
  p11reset <- sapply(time,function(t) KM(0,t,support12_reset$n.event,support12_reset$n.risk,support12_reset$time))
  p12reset <- 1 - p11reset

  df_proba <- data.frame("time"=rep(time,9),"proba"=c(p00,p01,p02,p11,p12,p01reset,p02reset,p11reset,p12reset),"courbes"=rep(c("p00","p01","p02","p11","p12","p01","p02","p11","p12"),each=length(time)),"etat_initial"=c(rep("Etat initial = 1",length(time)*3),rep("Etat initial = 2",length(time)*2),rep(c("Etat initial = 1","Etat initial = 2"),each=length(time)*2)),"debut"=c(rep("From 0",5*length(time)),rep("From state 1",4*length(time))))
  ggplot(df_proba)+
    geom_step(aes(time,proba,color=courbes,linetype=debut))+
    facet_wrap(~etat_initial)+
    theme_minimal()+
    coord_cartesian(ylim = c(0,1),xlim=c(0,time_limit))
}
