#' Title
#'
#' @param n
#' @param l01
#' @param l02
#' @param l12
#'
#' @return
#' @export
#'
#' @examples
process <- function(n,l01,l02,l12){
  t1 <- rexp(n,l01+l02)
  s1 <- rbinom(n,1,l01/(l01+l02))+1
  t2 <- rexp(n,l12)

  df <- data.frame("DSS"=rep(1,n),"DSS.time"=ifelse(s1==1,t1+t2,t1),
                   "T01"=-(s1-2),"T01.time"=t1,
                   "T02"=ifelse(s1==2,1,0),"T02.time"=ifelse(s1==2,t1,t1+t2),
                   "T12"=-(s1-2),"T12.time"=ifelse(s1==1,t1+t2,t1),
                   "T12reset"=-(s1-2),"T12reset.time"=ifelse(s1==1,t2,t1))
  return(df)
}
