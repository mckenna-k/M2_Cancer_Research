library(shiny)
library(shinydashboard)
library(ggplot2)
library(survival)

ui <- dashboardPage(
  dashboardHeader(title = 'Cancer trends'),
  dashboardSidebar(
    sidebarMenu(
      id = "tabs",
      menuItem("Simulations", tabName = "simu", icon = NULL),
      menuItem("Data", tabName = "data", icon = NULL),
      menuItem("Cox", tabName = "cox", icon = NULL)
    ),
    conditionalPanel("input.tabs == 'simu'",
                     numericInput("nbIndivSimu","Nombre d'individus",value=100,min=1,max=1000),
                     numericInput("l01","Paramètre de transition 0 à 1",value=0.3,min=0.01,max=10),
                     numericInput("l12","Paramètre de transition 1 à 2",value=0.3,min=0.01,max=10),
                     numericInput("l02","Paramètre de transition 0 à 2",value=0.3,min=0.01,max=10)
    ),
    conditionalPanel("input.tabs == 'data'",
                     uiOutput("cancerTypeUI"),
                     sliderInput("time","limit x-axis",min=1,max=30,value=10)
    ),
    conditionalPanel("input.tabs == 'cox'",
                     uiOutput("cancerTypeCoxUI")
    )
  ),
  dashboardBody(
    tabItems(
      tabItem("simu",
              plotOutput("survPlotSimu"),
              plotOutput("probPlotSimu"),
      ),
      tabItem("data",
              fluidRow(
                plotOutput("survPlot"),
                plotOutput("probPlot"),
                textOutput("nbIndiv")
              )
      ),
      tabItem("cox",
              fluidRow(
                plotOutput("survPlotCox"),
                tableOutput("coxCoeff")
              )
      )
    )
  )
)

server <- function(input, output){
  TCGA <- reactiveValues(data=get("TCGA","package:survCancer",inherits = FALSE))
  df_data <- reactiveVal()
  df_data_stage <- reactiveVal()

  observeEvent(TCGA$data,{
    data <- TCGA$data
    data <- data[-3042,] #PFI after OS/DSS

    data$DSS.time <- as.numeric(data$DSS.time)
    data$DSS <- as.numeric(data$DSS)
    data$PFI.time <- as.numeric(data$PFI.time)
    data$PFI <- as.numeric(data$PFI)

    pfiNotDead.time <- data$PFI.time/365.25
    pfiNotDead <- data$PFI
    pfiNotDead[data$PFI.time==data$DSS.time] <- 0
    dssDirect.time <- data$DSS.time/365.25
    dssDirect <- data$DSS
    dssDirect[!data$PFI.time==data$DSS.time] <- 0
    dssRelapse.time <- data$DSS.time/365.25
    dssRelapse <- data$DSS
    dssRelapse[data$PFI.time==data$DSS.time] <- 0
    emit <- data$PFI.time
    emit[data$PFI.time==data$DSS.time] <- 0
    dssRelapseReset.time <- (data$DSS.time-emit)/365.25
    dssRelapseReset <- data$DSS
    dssRelapseReset[data$PFI.time==data$DSS.time] <- 0
    stage <- as.factor(data$ajcc_pathologic_tumor_stage)
    levels(stage) <- c("I - II","I - II","I - II","I - II","III - IV","I - II","III - IV","III - IV","NA","other","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","I - II","III - IV","III - IV","III - IV","III - IV","III - IV","III - IV","I - II","III - IV","III - IV","III - IV","III - IV","other")

    df_new <- data.frame("DSS"=data$DSS,"DSS.time"=data$DSS.time/365.25,
                          "T01"=pfiNotDead,"T01.time"=pfiNotDead.time,
                          "T02"=dssDirect,"T02.time"=dssDirect.time,
                          "T12"=dssRelapse,"T12.time"=dssRelapse.time,
                          "T12reset"=dssRelapseReset,"T12reset.time"=dssRelapseReset.time,
                          stage,"type"=data$type)
    df_new <- df_new[-which(apply(df_new,1,function(x) any(is.na(x)))),]
    df_data(df_new)
    df_new <- df_new[-which(is.element(df_new$stage,c("NA","other"))),]
    df_new$stage <- factor(df_new$stage,c("I - II","III - IV"))
    df_data_stage(df_new)
  })

  data_simu <- reactiveVal()

  observeEvent({input$nbIndivSimu
    input$l01
    input$l02
    input$l12},{
      data_simu(process(input$nbIndivSimu,input$l01,input$l02,input$l12))
    })

  output$survPlotSimu <- renderPlot({ plot_process_KM(data_simu()) })
  output$probPlotSimu <- renderPlot({ plot_process_prob(data_simu()) })

  output$cancerTypeUI <- renderUI({
    selectInput("cancerType","Cancer types",choices=unique(df_data()$type),selected = "CHOL")
  })

  output$survPlot <- renderPlot({
    req(input$cancerType,input$time)
    df <- df_data()[df_data()$type==input$cancerType,]
    plot_process_KM(df)
  })

  output$probPlot <- renderPlot({
    req(input$cancerType,input$time)
    df <- df_data()[df_data()$type==input$cancerType,]
    plot_process_prob(df)
  })

  output$nbIndiv <- renderText({
    req(input$cancerType)
    df <- df_data()[df_data()$type==input$cancerType,]
    print(paste0("Nombre d'individus = ",nrow(df)))
  })

  output$cancerTypeCoxUI <- renderUI({
    selectInput("cancerTypeCox","Cancer types",choices=unique(df_data()$type),selected = "CHOL")
  })

  output$survPlotCox <- renderPlot({
    req(input$cancerTypeCox)
    df <- df_data_stage()[df_data_stage()$type==input$cancerTypeCox,]
    plot_process_KM(df,rep(df$stage,5))
  })

  output$coxCoeff <- renderTable({
    req(input$cancerTypeCox)
    df <- df_data_stage()[df_data_stage()$type==input$cancerTypeCox,]
    res <- t(sapply(seq(1,10,2),function(i) summary(coxph(Surv(df[,i+1],df[,i])~stage,data=df))$coefficients[c(2,5)]))
    rownames(res) <- c("DSS","T01","T02","T12","T12reset")
    colnames(res) <- colnames(summary(coxph(Surv(df[,2],df[,1])~stage,data=df))$coefficients)[c(2,5)]
    res
  },rownames=TRUE)
}
shinyApp(ui,server)

